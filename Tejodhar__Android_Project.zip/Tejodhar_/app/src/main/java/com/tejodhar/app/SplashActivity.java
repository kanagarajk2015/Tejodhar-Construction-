package com.tejodhar.app;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.widget.TextView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SplashActivity extends Activity {

    private static final int SPLASH_DURATION = 3200;
    private static final float TICKER_SPEED_DP_PER_SEC = 150f;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private ValueAnimator tickerAnimator;
    private final Runnable goToMain = new Runnable() {
        @Override
        public void run() {
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
            finish();
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );

        setContentView(R.layout.activity_splash);

        final View root = findViewById(R.id.splashRoot);
        final View band = findViewById(R.id.tickerBand);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, windowInsets) -> {
            Insets bars = windowInsets.getInsets(
                WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            v.setPadding(bars.left, bars.top, bars.right, 0);
            band.setPadding(0, 0, 0, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });

        setupTicker();

        handler.postDelayed(goToMain, SPLASH_DURATION);
    }

    /** "We Build Trust, Tomorrow Dreams" running from right to left, repeating. */
    private void setupTicker() {
        final View clip = findViewById(R.id.tickerClip);
        final TextView text = findViewById(R.id.tickerText);

        String p1 = getString(R.string.slogan_part1);
        String p2 = getString(R.string.slogan_part2);
        SpannableString sp = new SpannableString(p1 + p2);
        sp.setSpan(new ForegroundColorSpan(Color.parseColor("#FACC15")),
            p1.length(), p1.length() + p2.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        text.setText(sp);

        clip.post(() -> {
            final float start = clip.getWidth();
            final float end = -text.getWidth();
            final float density = getResources().getDisplayMetrics().density;
            long duration = (long) ((start - end) / (TICKER_SPEED_DP_PER_SEC * density) * 1000f);

            text.setTranslationX(start);
            tickerAnimator = ValueAnimator.ofFloat(start, end);
            tickerAnimator.setDuration(Math.max(duration, 1500L));
            tickerAnimator.setInterpolator(new LinearInterpolator());
            tickerAnimator.setRepeatCount(ValueAnimator.INFINITE);
            tickerAnimator.addUpdateListener(a -> text.setTranslationX((float) a.getAnimatedValue()));
            tickerAnimator.start();
        });
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(goToMain);
        if (tickerAnimator != null) tickerAnimator.cancel();
        super.onDestroy();
    }
}
