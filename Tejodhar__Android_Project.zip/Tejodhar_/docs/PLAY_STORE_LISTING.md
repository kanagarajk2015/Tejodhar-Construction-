# Google Play listing - Tejodhar

## Store listing text

**App name** (max 30): `Tejodhar`

**Short description** (max 80):
`Employee, attendance and payroll portal for Tejodhar Construction.`

**Full description** (max 4000):

Tejodhar is the official work portal of Tejodhar Construction. Sign in with the username and password given by your Admin/HR and manage your work from your phone.

What you can do:
- View attendance and your calendar, holidays and leave
- See salary details, advances and download payslips
- Contractors: manage assigned work, bills and records
- Site security staff: site-wise login and daily duties
- Upload photos and documents (bills, receipts, ID photo) using the camera or your files
- Scan QR codes inside the portal
- Download reports and CSV exports to your phone
- Get push notifications when available
- Optional fingerprint, face or screen-lock protection to open the app

Secure by design: access is by company-issued accounts only, there is one active login per account, the session logs out after inactivity, and data travels over HTTPS.

No ads. We do not sell your data. Read our privacy policy at https://tejodhar.in/privacy-policy.html

*Note: you need an account created by Tejodhar Construction to use this app.*

**Category:** Business (the template defaulted to Productivity; Business fits an HR / payroll tool better)
**Tags:** Business, HR, Attendance, Payroll
**Contact email / phone / website:** your company email, phone, https://tejodhar.in
**Privacy policy URL:** the address where you host `privacy-policy.html`, for example https://tejodhar.in/privacy-policy.html

## Graphics you still need to supply
- App icon 512 x 512 PNG (use the TD logo on a white background; max 1 MB)
- Feature graphic 1024 x 500 PNG
- At least 2 phone screenshots (login page with the running slogan, home/dashboard, payslip)

## Release notes (first release)
`First release of the Tejodhar app.`

## App content answers (Play Console > Policy > App content)
- **Privacy policy:** URL above.
- **Ads:** No ads.
- **App access:** Restricted. Provide Play reviewers with a **test username and password** (create a dummy employee login with no real data) and write "Accounts are issued by the company; use the credentials above". Without this the review will be rejected.
- **Target audience:** 18 and over. Not designed for children.
- **Content rating:** answer the questionnaire honestly: no violence, no user-generated public content, no location sharing. Expect "Everyone".
- **Government / news / health / financial-features declarations:** none apply. The app shows the user's own payslip and attendance records only, and offers no loans, payments or trading.
- **Account deletion:** accounts are created by the company, not by users, so the in-app deletion requirement does not apply. State that requests go to Admin/HR or your contact email.

## Data safety form (Play Console > App content > Data safety)
Collects data: **Yes**. Shared with third parties: **No** (Firebase acts as a service provider). Encrypted in transit: **Yes**. Users can request deletion: **Yes** (by contacting the company).

| Data type | Collected | Purpose | Optional? |
|---|---|---|---|
| Personal info: name, user ID, email/phone, date of birth | Yes | App functionality, account management | Required |
| Financial info: salary, payment / payslip details, expense records | Yes | App functionality | Required |
| Photos | Yes (only when you upload) | App functionality | Optional |
| Files and docs (bills, PDFs) | Yes (only when you upload) | App functionality | Optional |
| App activity (attendance, in-app records) | Yes | App functionality | Required |
| Device or other IDs: FCM push token | Yes | App functionality (notifications) | Optional |
| Location, contacts, messages, audio, health | No | | |

Biometric note: fingerprint/face checks are done by Android and never reach the app or server, so they are not "collected".

## Things to know before you submit
- **Developer account:** a new *personal* Play account must run a closed test with at least 12 testers for 14 days before it can publish to production. An *organisation* account does not have this step. Check the current rule in Play Console.
- **Target API:** the project targets Android 16 (API 36), which Google Play now requires for new apps and updates.
- **Increase `versionCode`** on every upload.
- **Push notifications:** the website has no `fcm_token.php` or `notifications.php` yet. The app will run fine, but notifications will not arrive until those are built on the server.
