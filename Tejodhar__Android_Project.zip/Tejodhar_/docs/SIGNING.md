# Signing the release (Play Store)

Google Play needs a **signed Android App Bundle (.aab)**. Do this once.

## 1. Create your upload key (keep it safe)

Run on your PC (JDK includes `keytool`):

```
keytool -genkeypair -v -keystore release-key.jks -alias tejodhar -keyalg RSA -keysize 2048 -validity 10000
```

Choose strong passwords and write them down. **Back up `release-key.jks` and the passwords in at least two safe places.**
Never commit them to GitHub or share them in chat.

When you create the app in Play Console, keep **Play App Signing** switched on (default). Then the key above is only your *upload key* and Google can reset it if you ever lose it.

## 2a. Build locally (Android Studio / Gradle)

1. Put `release-key.jks` next to `settings.gradle`.
2. Copy `keystore.properties.example` to `keystore.properties` and fill in the passwords.
3. Run `gradle :app:bundleRelease` (or Build > Generate Signed Bundle). Output:
   `app/build/outputs/bundle/release/app-release.aab`

## 2b. Build on GitHub Actions

1. Convert the key to text: `base64 -w0 release-key.jks` (macOS: `base64 -i release-key.jks`).
2. GitHub repo > Settings > Secrets and variables > Actions > New repository secret. Add four secrets:
   `KEYSTORE_BASE64` (the text from step 1), `KEYSTORE_PASSWORD`, `KEY_ALIAS` (`tejodhar`), `KEY_PASSWORD`.
3. Run the workflow. Download the **release-aab** artifact and upload it in Play Console.

Without these secrets the workflow still builds the debug APK and skips the release build.

## Before each new upload
Increase `versionCode` (and `versionName`) in `app/build.gradle`. Play rejects a repeated versionCode.
